# Experiment Two: The Battle of Architectures

This directory contains a preregistered, reproducible benchmark comparing static
instruction accumulation with dynamic semantic routing.

## Architecture

- Route A: one `gpt-4o-2024-11-20` inference with a synthetic 8K-token corporate instruction layer.
- Route B: one `gpt-4o-mini-2024-07-18` micro-router inference followed by one `gpt-4o-2024-11-20` executor inference.

The God Prompt is synthetic and is not a leaked, copied, or estimated proprietary
system prompt from any company.

## Directory Structure

- `fixed_artifacts/`: immutable inputs, prompts, gold standard, configuration, and architecture.
- `runs/<UTC_RUN_ID>/`: raw attempts, logical observations, paired analysis, figures,
  hashes, report, and publication ZIP.

## Reproduction

1. Use Python 3.11 or newer.
2. Install dependencies with `python -m pip install -r requirements.txt`.
3. Set the server-side environment variable `OPENAI_API_KEY`.
4. Validate with `python experiment_two.py --dry-run`.
5. Run `python experiment_two.py --iterations 50 --warmups 2`.

Running the paid experiment incurs OpenAI API costs. The script uses immutable model
snapshots for publication, explicit rate-limit admission control, append-only attempt
logs, fixed-artifact SHA-256 hashes, and a resumable checkpoint.
