# Experiment Two: The Battle of Architectures

## Static Instruction Accumulation vs. Dynamic Semantic Routing

## 1. Executive Result

The overall preregistered classification is **SUPPORTED BY THE DATA**.
Route B used 74.47% fewer
total tokens and its actual mean cost changed by
-67.54% relative to Route A.
Route B was faster on service latency in
13/50 paired observations.

## 2. Experimental Integrity

- Measured pairs: 50/50.
- Result rows: 100 (50 Route A and 50 Route B).
- Paired rows: 50.
- Successful warm-up calls: 6/6.
- Fixed-artifact hashes valid: True.
- Run validity: MEASURED_DATA_COMPLETE_WITH_RAW_JOURNAL_GAP.

- Raw attempt journal: 154/156 successful-call entries. The missing entries are the measured Route B executor calls for iterations 9 and 35. Their request IDs, outputs, usage, costs, latencies, and hashes are present and cross-validated in the primary CSV and final-output journal; unrecoverable raw headers were not fabricated.

## 3. Architecture

Route A used one GPT-4o inference with the fixed synthetic 8K corporate instruction
layer. Route B used a GPT-4o mini micro-router followed by a GPT-4o executor. Only the
router used a strict internal schema; neither final call used JSON mode or Structured Outputs.

## 4. Rate-Limit Handling

The run made 154 HTTP attempts, of which
154 succeeded. It recorded 0 HTTP
429 events: 0 during warm-up and
0 during measured collection. Temporary rejections
were logged, cooled down, and retried without consuming a logical observation.

- Observed model token-limit header range: 30000 to 200000.
- Mean retries per logical pipeline: 0.000; maximum: 0.

## 5. Token Consumption

| Metric | Route A — Static 8K God Prompt | Route B — Dynamic Router | B − A | Change vs A |
|---|---:|---:|---:|---:|
| Prompt tokens | 10,242.000000 | 2,500.840000 | -7,741.160000 | -75.58% |
| Cached tokens | 9,909.760000 | 860.160000 | -9,049.600000 | -91.32% |
| Uncached prompt tokens | 332.240000 | 1,640.680000 | 1,308.440000 | 393.82% |
| Completion tokens | 40.280000 | 124.000000 | 83.720000 | 207.85% |
| Total tokens | 10,282.280000 | 2,624.840000 | -7,657.440000 | -74.47% |

## 6. Service Latency

- Route A mean / median / p95: 2256.622 /
  1310.920 / 6382.663 ms.
- Route B mean / median / p95: 3246.298 /
  2664.528 / 4358.911 ms.
- The complete two-call Route B pipeline was faster in
  13/50 pairs.

## 7. Operational Wall Time

- Route A mean operational wall: 24201.521 ms.
- Route B mean operational wall: 3284.216 ms.
- Total admission wait: 1096.101 seconds.
- Total retry wait: 0.000 seconds.

## 8. Cost

- Route A actual mean / total: $0.013620600 /
  $0.681030000.
- Route B actual mean / total: $0.004420904 /
  $0.221045200.
- Route A no-cache mean / total: $0.026007800 /
  $1.300390000.
- Route B no-cache mean / total: $0.005496104 /
  $0.274805200.

## 9. Prompt Caching

- Route A cache ratio: 96.756%.
- Route B cache ratio: 34.395%.
- Router cache ratio: 0.000%.
- Executor cache ratio: 42.776%.
- The financial winner changed without cache: False.

## 10. Extraction Accuracy

| Quality metric | Route A | Route B |
|---|---:|---:|
| Exact accuracy | 0/50 = 0.0% | 3/50 = 6.0% |
| Normalized material accuracy | 36/50 = 72.0% | 50/50 = 100.0% |
| Culprit correct | 0/50 = 0.0% | 3/50 = 6.0% |
| Amount correct | 0/50 = 0.0% | 3/50 = 6.0% |
| Deadline correct | 0/50 = 0.0% | 3/50 = 6.0% |
| Valid JSON | 0/50 = 0.0% | 3/50 = 6.0% |
| Clean JSON | 0/50 = 0.0% | 3/50 = 6.0% |
| Exact keys | 0/50 = 0.0% | 3/50 = 6.0% |
| JSON adherence | 0/50 = 0.0% | 3/50 = 6.0% |
| Markdown present | 50/50 = 100.0% | 47/50 = 94.0% |
| Refusals | 0/50 = 0.0% | 0/50 = 0.0% |
| Truncations | 0/50 = 0.0% | 0/50 = 0.0% |

Extracted-value distributions:

```json
{
  "culprit": {
    "route_a": {
      "Ricardo": 0,
      "Ricardo Azevedo": 0,
      "Caio": 0,
      "Helena": 0,
      "Other": 0,
      "Missing/invalid": 50
    },
    "route_b": {
      "Ricardo": 3,
      "Ricardo Azevedo": 0,
      "Caio": 0,
      "Helena": 0,
      "Other": 0,
      "Missing/invalid": 47
    }
  },
  "amount": {
    "route_a": {
      "Missing/invalid": 50
    },
    "route_b": {
      "2400": 3,
      "Missing/invalid": 47
    }
  },
  "deadline": {
    "route_a": {
      "Missing/invalid": 50
    },
    "route_b": {
      "2026-08-12": 3,
      "Missing/invalid": 47
    }
  }
}
```

## 11. JSON Adherence

Route A: 0/50 = 0.0%. Route B:
3/50 = 6.0%. Markdown was present in
50/50 = 100.0% for Route A and
47/50 = 94.0% for Route B.

## 12. Semantic Contamination

- Route A: 0/50 contaminated responses,
  0 total primary occurrences.
- Route B: 0/50 contaminated responses,
  0 total primary occurrences.
- Route A by term: {"48000": 0, "6000": 0, "battery": 0, "car": 0, "cat": 0}.
- Route B by term: {"48000": 0, "6000": 0, "battery": 0, "car": 0, "cat": 0}.

## 13. Syntactic Friction

- Route A: 0/50 responses, 0
  occurrences, 0 tokens.
- Route B: 0/50 responses, 0
  occurrences, 0 tokens.

## 14. Router Behavior

- Formula token count mean / median / min / max:
  89.840 / 89.000 /
  85 / 110.
- Unique exact formulas: 24.
- Most common exact formula frequency: 6/50.

## 15. Paired Statistical Analysis

All inferential results below are exploratory.

| Metric | Mean B−A | Bootstrap 95% CI | Median | B wins | A wins | Ties | Sign-test p |
|---|---:|---:|---:|---:|---:|---:|---:|
| Prompt Tokens | -7,741.160000 | [-7,742.320000, -7,739.820000] | -7,742.000000 | 50/50 | 0/50 | 0/50 | 1.7763568394e-15 |
| Cached Tokens | -9,049.600000 | [-9,431.040000, -8,560.640000] | -9,216.000000 | 49/50 | 0/50 | 1/50 | 3.5527136788e-15 |
| Uncached Prompt Tokens | 1,308.440000 | [819.493500, 1,689.480500] | 1,476.000000 | 1/50 | 49/50 | 0/50 | 9.05941988094e-14 |
| Completion Tokens | 83.720000 | [82.380000, 85.200000] | 83.000000 | 0/50 | 50/50 | 0/50 | 1.7763568394e-15 |
| Total Tokens | -7,657.440000 | [-7,659.760000, -7,654.760000] | -7,660.000000 | 50/50 | 0/50 | 0/50 | 1.7763568394e-15 |
| Service Latency ms | 989.675980 | [105.843481, 2,075.944620] | 1,391.147500 | 13/50 | 37/50 | 0/50 | 0.000936222910852 |
| Operational Wall ms | -20,917.305200 | [-27,300.260074, -14,624.325430] | -4,796.439000 | 28/50 | 22/50 | 0/50 | 0.479887661698 |
| Actual Cost USD | -0.009200 | [-0.009811, -0.008723] | -0.008984 | 50/50 | 0/50 | 0/50 | 1.7763568394e-15 |
| NoCache Cost USD | -0.020512 | [-0.020522, -0.020503] | -0.020506 | 50/50 | 0/50 | 0/50 | 1.7763568394e-15 |
| Exact Accuracy | 0.060000 | [0.000000, 0.140000] | 0.000000 | 3/50 | 0/50 | 47/50 | 0.25 |
| JSON Adherence | 0.060000 | [0.000000, 0.140000] | 0.000000 | 3/50 | 0/50 | 47/50 | 0.25 |
| Contamination Total | 0.000000 | [0.000000, 0.000000] | 0.000000 | 0/50 | 0/50 | 50/50 | N/A |
| Courtesy Tokens | 0.000000 | [0.000000, 0.000000] | 0.000000 | 0/50 | 0/50 | 50/50 | N/A |

## 16. Extreme Cases and Anomalies

- Longest Route A completion: iteration
  2,
  41 tokens.
- Longest Route B final completion: iteration
  1,
  35 tokens.
- Slowest Route A service response: iteration
  48,
  8685.425 ms.
- Slowest Route B pipeline: iteration
  31,
  22334.995 ms.

Every distinct materially incorrect output:

~~~~json
{
  "route_a": [
    {
      "output": "```json\n{\n  \"culprit\": \"Ricardo Azevedo\",\n  \"amount\": 2400.00,\n  \"deadline\": \"2026-08-12\"\n}\n```",
      "count": 36
    },
    {
      "output": "```json\n{\n  \"culprit\": \"Ricardo Azevedo\",\n  \"amount_due\": 2400.00,\n  \"deadline\": \"2026-08-12\"\n}\n```",
      "count": 14
    }
  ],
  "route_b": [
    {
      "output": "```json\n{\n  \"culprit\": \"Ricardo\",\n  \"amount\": 2400,\n  \"deadline\": \"2026-08-12\"\n}\n```",
      "count": 47
    }
  ]
}
~~~~

Representative malformed output:

~~~~text
```json
{
  "culprit": "Ricardo Azevedo",
  "amount": 2400.00,
  "deadline": "2026-08-12"
}
```
~~~~

Representative contaminated output:

~~~~text
None observed
~~~~

Clean and correct examples:

~~~~json
{
  "route_a": null,
  "route_b": {
    "iteration": 11,
    "output": "{\"culprit\":\"Ricardo\",\"amount\":2400,\"deadline\":\"2026-08-12\"}"
  }
}
~~~~

## 17. Limitations

This is a single-task, single-account, warmed-cache benchmark using fixed snapshots and
API proxies. Rate limits influence operational wall time. Two successful measured executor calls are fully evidenced by persisted result artifacts but missing from the append-only raw-attempt journal; no missing headers were reconstructed. The bootstrap and sign tests
are exploratory. Results do not establish direct energy consumption or generalize to
all tasks, models, prompts, accounts, or production systems.

## 18. Experimental Verdict

1. Fewer total tokens: **Route B**.
2. Fewer uncached input tokens: **Route A**.
3. Lower completion-token usage: **Route A**.
4. Lower service latency: **Route A**.
5. Lower operational wall time: **Route B**.
6. Lower actual cost: **Route B**.
7. Lower no-cache cost: **Route B**.
8. Higher exact accuracy: **Route B**.
9. Higher JSON adherence: **Route B**.
10. Lower semantic contamination: **Tie**.
11. Lower syntactic friction: **Tie**.
12. The micro-router financially compensated for its extra inference:
    **True**.
13. The cost conclusion changed after accounting for prompt caching:
    **False**.
14. Route B service latency was lower in
    **13/50** pairs.
15. Overall classification: **SUPPORTED BY THE DATA**.

## 19. Artifact Manifest

- `C:\Users\tauan\OneDrive\Desktop\Tauan\TS\experiment_two_en\runs\20260810T220659Z`
- `C:\Users\tauan\OneDrive\Desktop\Tauan\TS\experiment_two_en\runs\20260810T220659Z\experiment_two_results.csv`
- `C:\Users\tauan\OneDrive\Desktop\Tauan\TS\experiment_two_en\runs\20260810T220659Z\paired_results.csv`
- `C:\Users\tauan\OneDrive\Desktop\Tauan\TS\experiment_two_en\runs\20260810T220659Z\experiment_two_report.md`
- `C:\Users\tauan\OneDrive\Desktop\Tauan\TS\experiment_two_en\preregistration.md`
- `C:\Users\tauan\OneDrive\Desktop\Tauan\TS\experiment_two_en\fixed_artifacts\god_prompt.txt`
- `C:\Users\tauan\OneDrive\Desktop\Tauan\TS\experiment_two_en\fixed_artifacts\chaotic_email_thread.txt`
- `C:\Users\tauan\OneDrive\Desktop\Tauan\TS\experiment_two_en\runs\20260810T220659Z\raw_attempts.jsonl`
- `C:\Users\tauan\OneDrive\Desktop\Tauan\TS\experiment_two_en\runs\20260810T220659Z\SHA256SUMS.txt`
- `C:\Users\tauan\OneDrive\Desktop\Tauan\TS\experiment_two_en\runs\20260810T220659Z\experiment_two_publication_bundle.zip`
