# Methodology

## Research Question

This benchmark tests whether dynamic semantic routing can outperform a large static
corporate instruction layer on a fixed noisy B2B extraction task.

## Route A

Route A sends one request to `gpt-4o-2024-11-20`. Its system message is a
deterministic synthetic God Prompt of approximately 8K tokens. Its user message is the
unchanged chaotic request followed by the unchanged email thread.

## Route B

Route B first sends only the chaotic request to `gpt-4o-mini-2024-07-18`. A strict
internal schema produces a five-part semantic execution formula. The compact formula
then becomes the sole system instruction for `gpt-4o-2024-11-20`, while the
email thread is its sole user message.

> The 8K-token God Prompt is a synthetic stress-test artifact designed for controlled comparison. It is not claimed to reproduce or estimate any specific company's proprietary production system prompt.

## Fixed Inputs and Gold Standard

The chaotic request, email thread, synthetic God Prompt, router prompt, request
architecture, configuration, and gold-standard JSON are fixed and hashed before the
first API call. The gold-standard file is used only by the offline evaluator and is
never inserted as an evaluation message or canonical answer in a model request.

## Stopping Rule

Collect exactly 50 logical paired observations. Temporary infrastructure admission failures such as HTTP 429, 408, connection errors, and 5xx responses are retried and logged but do not replace or consume an observation. A model response returned successfully by the API, including a wrong answer, malformed JSON, refusal, or truncation, is experimental data and must never be retried merely to improve quality.

## Warm-Up and Order

Two unmeasured warm-up pairs use the same payloads and parameters. Warm-up 1 runs A
then B; warm-up 2 runs B then A. Prompt caches are not cleared. The 50 measured pairs
alternate in the same way: odd iterations A then B, even iterations B then A.

## Rate-Aware Scheduler and Transport Retries

GPT-4o and GPT-4o mini maintain separate model-window state, while project-token state
is shared. Route A and Route B's executor use the same GPT-4o governor. Calls are
sequential. Admission uses locally estimated input plus the output cap, a 1.20 safety
factor, live rate-limit headers, and deterministic jitter. Temporary 429, 408, 409,
connection, timeout, and 5xx failures are logged and retried after bounded backoff.
Permanent authentication, model-access, billing, spend-limit, or credit failures are fatal.

## Latency Definitions

Service latency spans only the successful HTTP attempt. Route B service latency is the
sum of router and executor service latency. Admission wait, retry wait, and rejected
attempt latency are reported separately. Operational wall time contains the entire route,
including scheduler waits and transport retries.

## Tokens, Cache, and Cost

Prompt, cached, completion, and total tokens come only from API telemetry. Uncached
prompt tokens equal prompt tokens minus explicitly reported cached tokens. Costs use
`Decimal` and the pricing assumptions frozen in `experiment_config.json`. Observed
cost uses the cached-input price; the no-cache counterfactual prices every prompt token
at the uncached rate.

## Quality, Contamination, and Syntactic Friction

The primary evaluator parses the complete final output. Exact accuracy requires clean
native JSON, exact keys and types, and the exact gold values. Normalized material
accuracy is secondary and accepts only the preregistered normalizations. Contamination
and courtesy patterns inspect final model output only.

## Paired Statistical Analysis

Continuous metrics report route summaries, paired deltas, linear percentiles, a
20,000-resample deterministic bootstrap confidence interval for the mean delta, and an
exact two-sided sign test. Inferential results are exploratory.

## Limitations

The benchmark uses one fixed task, one account's live rate limits, one pair of model
snapshots, warmed prompt caches, and API-observed proxies rather than direct hardware
or energy measurements. Transport retries affect operational wall time but do not
replace model observations. Chat Completions has no documented exactly-once transport
guarantee if a client process dies after server completion but before local persistence.
