# Request Architecture

## Route A — Static 8K God Prompt

System:

```text
<GOD_PROMPT>
```

User:

```text
<CHAOTIC_USER_PROMPT>

=== EMAIL THREAD ===

<CHAOTIC_EMAIL_THREAD>
```

No response-format constraint is sent.

## Route B1 — Micro-Router

System:

```text
<ROUTER_SYSTEM_PROMPT>
```

User:

```text
<CHAOTIC_USER_PROMPT>
```

The strict internal JSON schema is enabled. The email thread is absent.

## Route B2 — Executor

System:

```text
<COMPACT_FORMULA_GENERATED_BY_B1>
```

User:

```text
<CHAOTIC_EMAIL_THREAD>
```

No response-format constraint is sent. The chaotic request and God Prompt are absent.
