# Sources

These sources document API behavior and model pricing. Empirical results are kept
separate and come only from the persisted run artifacts.

## Pricing assumptions

- GPT-4o model and pricing: https://developers.openai.com/api/docs/models/gpt-4o
- GPT-4o mini model, snapshot, and pricing: https://developers.openai.com/api/docs/models/gpt-4o-mini

The run freezes these pricing assumptions per one million tokens:

- GPT-4o: $2.50 uncached input, $1.25 cached input, $10.00 output.
- GPT-4o mini: $0.15 uncached input, $0.075 cached input, $0.60 output.

## Rate limits, headers, backoff, and request IDs

- API overview and rate-limit headers: https://developers.openai.com/api/reference/overview#debugging-requests
- Rate-limit guidance and exponential backoff: https://developers.openai.com/api/docs/guides/rate-limits

## Prompt caching

- Prompt caching guide: https://developers.openai.com/api/docs/guides/prompt-caching

## Python SDK and raw responses

- Official API libraries: https://developers.openai.com/api/docs/libraries
- Chat Completions reference: https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create

The implementation uses the official Python SDK's raw-response wrapper so the
whitelisted response headers and request ID can be persisted.
