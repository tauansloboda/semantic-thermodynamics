# Data Dictionary

## experiment_two_results.csv

| Name | Type | Units | Definition | Role |
|---|---|---|---|---|
| `Run_ID` | string | none | Logical route observation field: Run ID | primary |
| `Iteration` | integer or number | count | Logical route observation field: Iteration | primary |
| `Route` | string | none | Logical route observation field: Route | primary |
| `Execution_Order` | string | none | Logical route observation field: Execution Order | primary |
| `UTC_Time` | string | none | Logical route observation field: UTC Time | primary |
| `Status` | string | none | Logical route observation field: Status | primary |
| `Transport_Retries` | integer or number | count | Logical route observation field: Transport Retries | diagnostic |
| `HTTP_429_Count` | integer or number | count | Logical route observation field: HTTP 429 Count | primary |
| `Requested_Executor_Model` | string | none | Logical route observation field: Requested Executor Model | primary |
| `Returned_Executor_Model` | string | none | Logical route observation field: Returned Executor Model | primary |
| `Router_Model` | string | none | Logical route observation field: Router Model | primary |
| `Returned_Router_Model` | string | none | Logical route observation field: Returned Router Model | primary |
| `Router_Prompt_Tokens` | integer or number | count | Logical route observation field: Router Prompt Tokens | primary |
| `Router_Cached_Tokens` | integer or number | count | Logical route observation field: Router Cached Tokens | primary |
| `Router_Uncached_Prompt_Tokens` | integer or number | count | Logical route observation field: Router Uncached Prompt Tokens | primary |
| `Router_Completion_Tokens` | integer or number | count | Logical route observation field: Router Completion Tokens | primary |
| `Router_Total_Tokens` | integer or number | count | Logical route observation field: Router Total Tokens | primary |
| `Router_Service_Latency_ms` | number | milliseconds | Logical route observation field: Router Service Latency ms | primary |
| `Router_Admission_Wait_ms` | number | milliseconds | Logical route observation field: Router Admission Wait ms | diagnostic |
| `Router_Retry_Wait_ms` | number | milliseconds | Logical route observation field: Router Retry Wait ms | diagnostic |
| `Router_Rejected_Attempt_Latency_ms` | number | milliseconds | Logical route observation field: Router Rejected Attempt Latency ms | diagnostic |
| `Router_Cost_Actual_USD` | decimal string | USD | Logical route observation field: Router Cost Actual USD | primary |
| `Router_Cost_NoCache_USD` | decimal string | USD | Logical route observation field: Router Cost NoCache USD | primary |
| `Router_Request_ID` | string | none | Logical route observation field: Router Request ID | diagnostic |
| `Router_System_Fingerprint` | string | none | Logical route observation field: Router System Fingerprint | diagnostic |
| `Router_Finish_Reason` | string | none | Logical route observation field: Router Finish Reason | primary |
| `Router_Refusal` | string | none | Logical route observation field: Router Refusal | primary |
| `Formula_SHA256` | string | none | Logical route observation field: Formula SHA256 | diagnostic |
| `Formula_Tokens` | integer or number | count | Logical route observation field: Formula Tokens | diagnostic |
| `Executor_Prompt_Tokens` | integer or number | count | Logical route observation field: Executor Prompt Tokens | primary |
| `Executor_Cached_Tokens` | integer or number | count | Logical route observation field: Executor Cached Tokens | primary |
| `Executor_Uncached_Prompt_Tokens` | integer or number | count | Logical route observation field: Executor Uncached Prompt Tokens | primary |
| `Executor_Completion_Tokens` | integer or number | count | Logical route observation field: Executor Completion Tokens | primary |
| `Executor_Total_Tokens` | integer or number | count | Logical route observation field: Executor Total Tokens | primary |
| `Executor_Service_Latency_ms` | number | milliseconds | Logical route observation field: Executor Service Latency ms | primary |
| `Executor_Admission_Wait_ms` | number | milliseconds | Logical route observation field: Executor Admission Wait ms | diagnostic |
| `Executor_Retry_Wait_ms` | number | milliseconds | Logical route observation field: Executor Retry Wait ms | diagnostic |
| `Executor_Rejected_Attempt_Latency_ms` | number | milliseconds | Logical route observation field: Executor Rejected Attempt Latency ms | diagnostic |
| `Executor_Cost_Actual_USD` | decimal string | USD | Logical route observation field: Executor Cost Actual USD | primary |
| `Executor_Cost_NoCache_USD` | decimal string | USD | Logical route observation field: Executor Cost NoCache USD | primary |
| `Executor_Request_ID` | string | none | Logical route observation field: Executor Request ID | diagnostic |
| `Executor_System_Fingerprint` | string | none | Logical route observation field: Executor System Fingerprint | diagnostic |
| `Executor_Finish_Reason` | string | none | Logical route observation field: Executor Finish Reason | primary |
| `Executor_Refusal` | string | none | Logical route observation field: Executor Refusal | primary |
| `Prompt_Tokens_Total` | integer or number | count | Logical route observation field: Prompt Tokens Total | primary |
| `Cached_Tokens_Total` | integer or number | count | Logical route observation field: Cached Tokens Total | primary |
| `Uncached_Prompt_Tokens_Total` | integer or number | count | Logical route observation field: Uncached Prompt Tokens Total | primary |
| `Completion_Tokens_Total` | integer or number | count | Logical route observation field: Completion Tokens Total | primary |
| `Tokens_Total` | integer or number | count | Logical route observation field: Tokens Total | primary |
| `Route_Service_Latency_ms` | number | milliseconds | Logical route observation field: Route Service Latency ms | primary |
| `Route_Admission_Wait_ms` | number | milliseconds | Logical route observation field: Route Admission Wait ms | diagnostic |
| `Route_Retry_Wait_ms` | number | milliseconds | Logical route observation field: Route Retry Wait ms | diagnostic |
| `Route_Rejected_Attempt_Latency_ms` | number | milliseconds | Logical route observation field: Route Rejected Attempt Latency ms | diagnostic |
| `Route_Operational_Wall_ms` | number | milliseconds | Logical route observation field: Route Operational Wall ms | primary |
| `Cost_Actual_USD` | decimal string | USD | Logical route observation field: Cost Actual USD | primary |
| `Cost_NoCache_USD` | decimal string | USD | Logical route observation field: Cost NoCache USD | primary |
| `Final_Output` | string | none | Logical route observation field: Final Output | primary |
| `Final_Output_SHA256` | string | none | Logical route observation field: Final Output SHA256 | primary |
| `Valid_JSON` | integer | 0/1 | Logical route observation field: Valid JSON | primary |
| `Clean_JSON` | integer | 0/1 | Logical route observation field: Clean JSON | primary |
| `Markdown_Present` | integer | 0/1 | Logical route observation field: Markdown Present | diagnostic |
| `Exact_Keys` | string | none | Logical route observation field: Exact Keys | primary |
| `Exact_Types` | string | none | Logical route observation field: Exact Types | primary |
| `JSON_Adherence` | integer | 0/1 | Logical route observation field: JSON Adherence | primary |
| `Culprit_Extracted` | string | none | Logical route observation field: Culprit Extracted | primary |
| `Amount_Extracted` | string | none | Logical route observation field: Amount Extracted | primary |
| `Deadline_Extracted` | string | none | Logical route observation field: Deadline Extracted | primary |
| `Culprit_Correct` | integer | 0/1 | Logical route observation field: Culprit Correct | primary |
| `Amount_Correct` | integer | 0/1 | Logical route observation field: Amount Correct | primary |
| `Deadline_Correct` | integer | 0/1 | Logical route observation field: Deadline Correct | primary |
| `Fields_Correct_0_to_3` | integer | 0/1 | Logical route observation field: Fields Correct 0 to 3 | primary |
| `Exact_Accuracy` | integer | 0/1 | Logical route observation field: Exact Accuracy | primary |
| `Normalized_Material_Accuracy` | integer | 0/1 | Logical route observation field: Normalized Material Accuracy | primary |
| `Noise_Cat` | string | none | Logical route observation field: Noise Cat | diagnostic |
| `Noise_Car` | string | none | Logical route observation field: Noise Car | diagnostic |
| `Noise_Battery` | string | none | Logical route observation field: Noise Battery | diagnostic |
| `Noise_48000` | string | none | Logical route observation field: Noise 48000 | diagnostic |
| `Noise_6000` | string | none | Logical route observation field: Noise 6000 | diagnostic |
| `Contamination_Total` | string | none | Logical route observation field: Contamination Total | primary |
| `Contamination_Binary` | integer | 0/1 | Logical route observation field: Contamination Binary | primary |
| `Contamination_Terms` | string | none | Logical route observation field: Contamination Terms | primary |
| `Secondary_Noise_Tow_Truck` | string | none | Logical route observation field: Secondary Noise Tow Truck | diagnostic |
| `Secondary_Noise_Vet` | string | none | Logical route observation field: Secondary Noise Vet | diagnostic |
| `Secondary_Noise_4pct_Battery` | string | none | Logical route observation field: Secondary Noise 4pct Battery | diagnostic |
| `Secondary_Noise_July_31_2026` | string | none | Logical route observation field: Secondary Noise July 31 2026 | diagnostic |
| `Secondary_Noise_August_10_2026` | string | none | Logical route observation field: Secondary Noise August 10 2026 | diagnostic |
| `Secondary_Contamination_Total` | string | none | Logical route observation field: Secondary Contamination Total | diagnostic |
| `Secondary_Contamination_Binary` | integer | 0/1 | Logical route observation field: Secondary Contamination Binary | diagnostic |
| `Secondary_Contamination_Terms` | string | none | Logical route observation field: Secondary Contamination Terms | diagnostic |
| `Courtesy_Occurrences` | string | none | Logical route observation field: Courtesy Occurrences | diagnostic |
| `Courtesy_Tokens` | integer or number | count | Logical route observation field: Courtesy Tokens | diagnostic |
| `Courtesy_Terms` | string | none | Logical route observation field: Courtesy Terms | diagnostic |
| `Courtesy_Binary` | integer | 0/1 | Logical route observation field: Courtesy Binary | diagnostic |
| `Finish_Reason` | string | none | Logical route observation field: Finish Reason | primary |
| `Refusal_Present` | integer | 0/1 | Logical route observation field: Refusal Present | primary |
| `Truncated` | integer | 0/1 | Logical route observation field: Truncated | primary |
| `Request_ID` | string | none | Logical route observation field: Request ID | diagnostic |
| `System_Fingerprint` | string | none | Logical route observation field: System Fingerprint | diagnostic |

## paired_results.csv

| Name | Type | Units | Definition | Role |
|---|---|---|---|---|
| `Iteration` | integer or number | count | Paired-analysis field: Iteration | primary |
| `A_Prompt_Tokens` | integer or number | count | Paired-analysis field: A Prompt Tokens | primary |
| `B_Prompt_Tokens` | integer or number | count | Paired-analysis field: B Prompt Tokens | primary |
| `Delta_B_minus_A_Prompt_Tokens` | integer or number | count | Paired-analysis field: Delta B minus A Prompt Tokens | primary |
| `A_Wins_Prompt_Tokens` | integer or number | count | Paired-analysis field: A Wins Prompt Tokens | primary |
| `B_Wins_Prompt_Tokens` | integer or number | count | Paired-analysis field: B Wins Prompt Tokens | primary |
| `Tie_Prompt_Tokens` | integer or number | count | Paired-analysis field: Tie Prompt Tokens | primary |
| `A_Cached_Tokens` | integer or number | count | Paired-analysis field: A Cached Tokens | primary |
| `B_Cached_Tokens` | integer or number | count | Paired-analysis field: B Cached Tokens | primary |
| `Delta_B_minus_A_Cached_Tokens` | integer or number | count | Paired-analysis field: Delta B minus A Cached Tokens | primary |
| `A_Wins_Cached_Tokens` | integer or number | count | Paired-analysis field: A Wins Cached Tokens | primary |
| `B_Wins_Cached_Tokens` | integer or number | count | Paired-analysis field: B Wins Cached Tokens | primary |
| `Tie_Cached_Tokens` | integer or number | count | Paired-analysis field: Tie Cached Tokens | primary |
| `A_Uncached_Prompt_Tokens` | integer or number | count | Paired-analysis field: A Uncached Prompt Tokens | primary |
| `B_Uncached_Prompt_Tokens` | integer or number | count | Paired-analysis field: B Uncached Prompt Tokens | primary |
| `Delta_B_minus_A_Uncached_Prompt_Tokens` | integer or number | count | Paired-analysis field: Delta B minus A Uncached Prompt Tokens | primary |
| `A_Wins_Uncached_Prompt_Tokens` | integer or number | count | Paired-analysis field: A Wins Uncached Prompt Tokens | primary |
| `B_Wins_Uncached_Prompt_Tokens` | integer or number | count | Paired-analysis field: B Wins Uncached Prompt Tokens | primary |
| `Tie_Uncached_Prompt_Tokens` | integer or number | count | Paired-analysis field: Tie Uncached Prompt Tokens | primary |
| `A_Completion_Tokens` | integer or number | count | Paired-analysis field: A Completion Tokens | primary |
| `B_Completion_Tokens` | integer or number | count | Paired-analysis field: B Completion Tokens | primary |
| `Delta_B_minus_A_Completion_Tokens` | integer or number | count | Paired-analysis field: Delta B minus A Completion Tokens | primary |
| `A_Wins_Completion_Tokens` | integer or number | count | Paired-analysis field: A Wins Completion Tokens | primary |
| `B_Wins_Completion_Tokens` | integer or number | count | Paired-analysis field: B Wins Completion Tokens | primary |
| `Tie_Completion_Tokens` | integer or number | count | Paired-analysis field: Tie Completion Tokens | primary |
| `A_Total_Tokens` | integer or number | count | Paired-analysis field: A Total Tokens | primary |
| `B_Total_Tokens` | integer or number | count | Paired-analysis field: B Total Tokens | primary |
| `Delta_B_minus_A_Total_Tokens` | integer or number | count | Paired-analysis field: Delta B minus A Total Tokens | primary |
| `A_Wins_Total_Tokens` | integer or number | count | Paired-analysis field: A Wins Total Tokens | primary |
| `B_Wins_Total_Tokens` | integer or number | count | Paired-analysis field: B Wins Total Tokens | primary |
| `Tie_Total_Tokens` | integer or number | count | Paired-analysis field: Tie Total Tokens | primary |
| `A_Service_Latency_ms` | number | milliseconds | Paired-analysis field: A Service Latency ms | primary |
| `B_Service_Latency_ms` | number | milliseconds | Paired-analysis field: B Service Latency ms | primary |
| `Delta_B_minus_A_Service_Latency_ms` | number | milliseconds | Paired-analysis field: Delta B minus A Service Latency ms | primary |
| `A_Wins_Service_Latency_ms` | number | milliseconds | Paired-analysis field: A Wins Service Latency ms | primary |
| `B_Wins_Service_Latency_ms` | number | milliseconds | Paired-analysis field: B Wins Service Latency ms | primary |
| `Tie_Service_Latency_ms` | number | milliseconds | Paired-analysis field: Tie Service Latency ms | primary |
| `A_Operational_Wall_ms` | number | milliseconds | Paired-analysis field: A Operational Wall ms | primary |
| `B_Operational_Wall_ms` | number | milliseconds | Paired-analysis field: B Operational Wall ms | primary |
| `Delta_B_minus_A_Operational_Wall_ms` | number | milliseconds | Paired-analysis field: Delta B minus A Operational Wall ms | primary |
| `A_Wins_Operational_Wall_ms` | number | milliseconds | Paired-analysis field: A Wins Operational Wall ms | primary |
| `B_Wins_Operational_Wall_ms` | number | milliseconds | Paired-analysis field: B Wins Operational Wall ms | primary |
| `Tie_Operational_Wall_ms` | number | milliseconds | Paired-analysis field: Tie Operational Wall ms | primary |
| `A_Actual_Cost_USD` | decimal string | USD | Paired-analysis field: A Actual Cost USD | primary |
| `B_Actual_Cost_USD` | decimal string | USD | Paired-analysis field: B Actual Cost USD | primary |
| `Delta_B_minus_A_Actual_Cost_USD` | decimal string | USD | Paired-analysis field: Delta B minus A Actual Cost USD | primary |
| `A_Wins_Actual_Cost_USD` | decimal string | USD | Paired-analysis field: A Wins Actual Cost USD | primary |
| `B_Wins_Actual_Cost_USD` | decimal string | USD | Paired-analysis field: B Wins Actual Cost USD | primary |
| `Tie_Actual_Cost_USD` | decimal string | USD | Paired-analysis field: Tie Actual Cost USD | primary |
| `A_NoCache_Cost_USD` | decimal string | USD | Paired-analysis field: A NoCache Cost USD | primary |
| `B_NoCache_Cost_USD` | decimal string | USD | Paired-analysis field: B NoCache Cost USD | primary |
| `Delta_B_minus_A_NoCache_Cost_USD` | decimal string | USD | Paired-analysis field: Delta B minus A NoCache Cost USD | primary |
| `A_Wins_NoCache_Cost_USD` | decimal string | USD | Paired-analysis field: A Wins NoCache Cost USD | primary |
| `B_Wins_NoCache_Cost_USD` | decimal string | USD | Paired-analysis field: B Wins NoCache Cost USD | primary |
| `Tie_NoCache_Cost_USD` | decimal string | USD | Paired-analysis field: Tie NoCache Cost USD | primary |
| `A_Exact_Accuracy` | integer | 0/1 | Paired-analysis field: A Exact Accuracy | primary |
| `B_Exact_Accuracy` | integer | 0/1 | Paired-analysis field: B Exact Accuracy | primary |
| `Delta_B_minus_A_Exact_Accuracy` | integer | 0/1 | Paired-analysis field: Delta B minus A Exact Accuracy | primary |
| `A_Wins_Exact_Accuracy` | integer or number | count | Paired-analysis field: A Wins Exact Accuracy | primary |
| `B_Wins_Exact_Accuracy` | integer or number | count | Paired-analysis field: B Wins Exact Accuracy | primary |
| `Tie_Exact_Accuracy` | integer | 0/1 | Paired-analysis field: Tie Exact Accuracy | primary |
| `A_JSON_Adherence` | integer | 0/1 | Paired-analysis field: A JSON Adherence | primary |
| `B_JSON_Adherence` | integer | 0/1 | Paired-analysis field: B JSON Adherence | primary |
| `Delta_B_minus_A_JSON_Adherence` | integer | 0/1 | Paired-analysis field: Delta B minus A JSON Adherence | primary |
| `A_Wins_JSON_Adherence` | integer or number | count | Paired-analysis field: A Wins JSON Adherence | primary |
| `B_Wins_JSON_Adherence` | integer or number | count | Paired-analysis field: B Wins JSON Adherence | primary |
| `Tie_JSON_Adherence` | integer | 0/1 | Paired-analysis field: Tie JSON Adherence | primary |
| `A_Contamination_Total` | string | none | Paired-analysis field: A Contamination Total | primary |
| `B_Contamination_Total` | string | none | Paired-analysis field: B Contamination Total | primary |
| `Delta_B_minus_A_Contamination_Total` | string | none | Paired-analysis field: Delta B minus A Contamination Total | primary |
| `A_Wins_Contamination_Total` | integer or number | count | Paired-analysis field: A Wins Contamination Total | primary |
| `B_Wins_Contamination_Total` | integer or number | count | Paired-analysis field: B Wins Contamination Total | primary |
| `Tie_Contamination_Total` | integer | 0/1 | Paired-analysis field: Tie Contamination Total | primary |
| `A_Courtesy_Tokens` | integer or number | count | Paired-analysis field: A Courtesy Tokens | diagnostic |
| `B_Courtesy_Tokens` | integer or number | count | Paired-analysis field: B Courtesy Tokens | diagnostic |
| `Delta_B_minus_A_Courtesy_Tokens` | integer or number | count | Paired-analysis field: Delta B minus A Courtesy Tokens | diagnostic |
| `A_Wins_Courtesy_Tokens` | integer or number | count | Paired-analysis field: A Wins Courtesy Tokens | diagnostic |
| `B_Wins_Courtesy_Tokens` | integer or number | count | Paired-analysis field: B Wins Courtesy Tokens | diagnostic |
| `Tie_Courtesy_Tokens` | integer or number | count | Paired-analysis field: Tie Courtesy Tokens | diagnostic |

## rate_limit_events.csv

| Name | Type | Units | Definition | Role |
|---|---|---|---|---|
| `Iteration` | integer or number | count | Rate-limit audit field: Iteration | primary |
| `Route` | string | none | Rate-limit audit field: Route | primary |
| `Stage` | string | none | Rate-limit audit field: Stage | primary |
| `Attempt` | string | none | Rate-limit audit field: Attempt | primary |
| `UTC_Time` | string | none | Rate-limit audit field: UTC Time | primary |
| `HTTP_Status` | string | none | Rate-limit audit field: HTTP Status | primary |
| `Error_Code` | string | none | Rate-limit audit field: Error Code | primary |
| `Retry_After` | string | none | Rate-limit audit field: Retry After | diagnostic |
| `Remaining_Tokens` | integer or number | count | Rate-limit audit field: Remaining Tokens | primary |
| `Reset_Tokens` | integer or number | count | Rate-limit audit field: Reset Tokens | primary |
| `Remaining_Project_Tokens` | integer or number | count | Rate-limit audit field: Remaining Project Tokens | primary |
| `Reset_Project_Tokens` | integer or number | count | Rate-limit audit field: Reset Project Tokens | primary |
| `Remaining_Requests` | string | none | Rate-limit audit field: Remaining Requests | primary |
| `Reset_Requests` | string | none | Rate-limit audit field: Reset Requests | primary |
| `Calculated_Wait_Seconds` | string | none | Rate-limit audit field: Calculated Wait Seconds | primary |
| `Actual_Wait_Seconds` | string | none | Rate-limit audit field: Actual Wait Seconds | primary |
