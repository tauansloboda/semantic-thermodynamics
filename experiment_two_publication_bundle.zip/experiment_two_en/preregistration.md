# Experiment Two Preregistration

## Stopping Rule

> Collect exactly 50 logical paired observations. Temporary infrastructure admission failures such as HTTP 429, 408, connection errors, and 5xx responses are retried and logged but do not replace or consume an observation. A model response returned successfully by the API, including a wrong answer, malformed JSON, refusal, or truncation, is experimental data and must never be retried merely to improve quality.

## Primary Comparisons

Route B versus Route A on:

1. total tokens per completed pipeline;
2. service latency per completed pipeline;
3. actual monetary cost per completed pipeline;
4. exact extraction accuracy;
5. native JSON adherence.

## Secondary Comparisons

- completion tokens;
- uncached input tokens;
- prompt cache ratio;
- counterfactual no-cache cost;
- semantic contamination;
- syntactic friction;
- rate-limit admission burden;
- operational wall-clock latency;
- router-formula size.

## Directional Hypotheses

- H1: Route B will use fewer total tokens.
- H2: Route B will cost less per logical pipeline.
- H3: Route B will have higher native-JSON adherence.
- H4: Route B will have equal or higher exact extraction accuracy.
- H5: Route B service latency may be higher or lower because it pays for two sequential inferences; no directional latency claim is preregistered.

## Statistical Plan

All comparisons use 50 paired measured observations. Paired deltas are B minus A.
Exploratory inference uses a deterministic 20,000-resample percentile bootstrap
with seed 20260810 and an exact two-sided sign test excluding ties. No significance
threshold is treated as proof of the theory.
