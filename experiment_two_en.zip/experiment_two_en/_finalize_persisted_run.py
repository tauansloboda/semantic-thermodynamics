from __future__ import annotations

import json
from pathlib import Path

import experiment_two as exp
from matplotlib.axes import Axes


RUN_DIR = Path(__file__).resolve().parent / "runs" / "20260810T220659Z"
ITERATIONS = 50
WARMUPS = 2


_ORIGINAL_BOXPLOT = Axes.boxplot


def _compatible_boxplot(self: Axes, *args, **kwargs):
    if "labels" in kwargs and "tick_labels" not in kwargs:
        kwargs["tick_labels"] = kwargs.pop("labels")
    return _ORIGINAL_BOXPLOT(self, *args, **kwargs)


Axes.boxplot = _compatible_boxplot


def audit_final_outputs(result_rows: list[dict[str, str]]) -> dict[str, object]:
    records = exp.read_jsonl(RUN_DIR / "final_outputs.jsonl")
    if len(records) != 100:
        raise RuntimeError(f"Expected 100 final-output records; found {len(records)}.")
    result_index = {
        (int(row["Iteration"]), row["Route"]): row
        for row in result_rows
    }
    record_index = {
        (int(record["iteration"]), record["route"]): record
        for record in records
    }
    if len(result_index) != 100 or set(result_index) != set(record_index):
        raise RuntimeError("Final-output keys do not match the result CSV.")
    for key, row in result_index.items():
        record = record_index[key]
        if record["final_output"] != row["Final_Output"]:
            raise RuntimeError(f"Final output changed for {key}.")
        expected_hash = exp.sha256_text(row["Final_Output"])
        if row["Final_Output_SHA256"] != expected_hash:
            raise RuntimeError(f"Result CSV output hash mismatch for {key}.")
        if record["final_output_sha256"] != expected_hash:
            raise RuntimeError(f"Final-output journal hash mismatch for {key}.")
    return {
        "records": len(records),
        "unique_logical_outputs": len(record_index),
        "cross_file_hashes_match": True,
    }


def identify_raw_journal_gap(attempts: list[dict]) -> list[dict[str, object]]:
    observed = {
        (
            bool(record.get("warmup")),
            int(record["logical_iteration"]),
            str(record["route"]),
            str(record["stage"]),
        )
        for record in attempts
        if record.get("http_success") is True
    }
    expected = set()
    for iteration in range(1, ITERATIONS + 1):
        expected.add((False, iteration, "A_STATIC_GOD_PROMPT", "executor"))
        expected.add((False, iteration, "B_DYNAMIC_ROUTER", "router"))
        expected.add((False, iteration, "B_DYNAMIC_ROUTER", "executor"))
    missing = sorted(expected - observed)
    return [
        {
            "warmup": warmup,
            "iteration": iteration,
            "route": route,
            "stage": stage,
        }
        for warmup, iteration, route, stage in missing
    ]


def build_summary() -> dict[str, object]:
    result_rows = exp.read_csv_rows(RUN_DIR / "experiment_two_results.csv")
    if len(result_rows) != 100 or list(result_rows[0]) != exp.RESULT_COLUMNS:
        raise RuntimeError("The primary result CSV is incomplete or has the wrong schema.")
    a_rows = sorted(
        [row for row in result_rows if row["Route"] == "A_STATIC_GOD_PROMPT"],
        key=lambda row: int(row["Iteration"]),
    )
    b_rows = sorted(
        [row for row in result_rows if row["Route"] == "B_DYNAMIC_ROUTER"],
        key=lambda row: int(row["Iteration"]),
    )
    if len(a_rows) != 50 or len(b_rows) != 50:
        raise RuntimeError("The primary result CSV lacks 50 rows per route.")
    expected_iterations = list(range(1, 51))
    if [int(row["Iteration"]) for row in a_rows] != expected_iterations:
        raise RuntimeError("Route A iteration coverage is invalid.")
    if [int(row["Iteration"]) for row in b_rows] != expected_iterations:
        raise RuntimeError("Route B iteration coverage is invalid.")
    if any(
        row["Status"] not in ("ok", "truncated", "content_filter", "refusal", "empty_response")
        for row in result_rows
    ):
        raise RuntimeError("A measured route lacks a completed final response.")

    final_output_audit = audit_final_outputs(result_rows)
    paired_rows = exp.build_paired_rows(result_rows, ITERATIONS)
    exp.fsync_csv_rows(RUN_DIR / "paired_results.csv", exp.PAIRED_COLUMNS, paired_rows, mode="w")
    summary_rows = exp.build_summary_rows(paired_rows)
    exp.fsync_csv_rows(
        RUN_DIR / "summary_metrics.csv", exp.SUMMARY_COLUMNS, summary_rows, mode="w"
    )
    summary_by_metric = {row["Metric"]: row for row in summary_rows}

    a_summary = exp.route_summary(a_rows)
    b_summary = exp.route_summary(b_rows)
    router_summary = exp.stage_summary(b_rows, "Router")
    executor_summary = exp.stage_summary(b_rows, "Executor")
    attempts = exp.read_jsonl(RUN_DIR / "raw_attempts.jsonl")
    formulas = exp.read_jsonl(RUN_DIR / "router_formulas.jsonl")
    if len(formulas) != 50:
        raise RuntimeError(f"Expected 50 measured formulas; found {len(formulas)}.")
    manifest = exp.validate_manifest(RUN_DIR)
    rate_summary = exp.rate_limit_audit(attempts, result_rows)
    journal_gap = identify_raw_journal_gap(attempts)
    expected_gap = [
        {"warmup": False, "iteration": 9, "route": "B_DYNAMIC_ROUTER", "stage": "executor"},
        {"warmup": False, "iteration": 35, "route": "B_DYNAMIC_ROUTER", "stage": "executor"},
    ]
    if journal_gap != expected_gap:
        raise RuntimeError(f"Unexpected raw-journal gap: {journal_gap!r}")
    rate_summary.update(
        {
            "successful_logical_calls_evidenced_across_artifacts": 156,
            "raw_attempt_journal_success_entries": 154,
            "raw_attempt_journal_gap_count": 2,
            "raw_attempt_journal_gap": journal_gap,
        }
    )

    distributions = {
        "culprit": {
            "route_a": exp.value_distribution(
                a_rows, "Culprit_Extracted", ["Ricardo", "Ricardo Azevedo", "Caio", "Helena"]
            ),
            "route_b": exp.value_distribution(
                b_rows, "Culprit_Extracted", ["Ricardo", "Ricardo Azevedo", "Caio", "Helena"]
            ),
        },
        "amount": {
            "route_a": exp.value_distribution(a_rows, "Amount_Extracted"),
            "route_b": exp.value_distribution(b_rows, "Amount_Extracted"),
        },
        "deadline": {
            "route_a": exp.value_distribution(a_rows, "Deadline_Extracted"),
            "route_b": exp.value_distribution(b_rows, "Deadline_Extracted"),
        },
    }
    formula_summary = exp.formula_audit(formulas)
    extremes = exp.extreme_cases(a_rows, b_rows)
    verdict = exp.build_verdict(a_summary, b_summary, summary_by_metric)
    artifacts = {
        "run_directory": str(RUN_DIR.resolve()),
        "results_csv": str((RUN_DIR / "experiment_two_results.csv").resolve()),
        "paired_csv": str((RUN_DIR / "paired_results.csv").resolve()),
        "report": str((RUN_DIR / "experiment_two_report.md").resolve()),
        "preregistration": str((exp.PROJECT_DIR / "preregistration.md").resolve()),
        "god_prompt": str((exp.FIXED_DIR / "god_prompt.txt").resolve()),
        "email_thread": str((exp.FIXED_DIR / "chaotic_email_thread.txt").resolve()),
        "raw_attempts": str((RUN_DIR / "raw_attempts.jsonl").resolve()),
        "sha256sums": str((RUN_DIR / "SHA256SUMS.txt").resolve()),
        "publication_zip": str((RUN_DIR / "experiment_two_publication_bundle.zip").resolve()),
    }
    environment = json.loads((RUN_DIR / "environment.json").read_text(encoding="utf-8"))
    summary: dict[str, object] = {
        "schema_version": "1.0",
        "run_id": RUN_DIR.name,
        "integrity": {
            "measured_pairs": 50,
            "result_rows": 100,
            "route_a_rows": 50,
            "route_b_rows": 50,
            "paired_rows": 50,
            "warmup_successful_calls": 6,
            "measured_successful_logical_calls": 150,
            "fixed_hashes_match": True,
            "final_outputs_cross_validated": final_output_audit,
            "raw_attempt_journal_gap_count": 2,
            "run_validity": "MEASURED_DATA_COMPLETE_WITH_RAW_JOURNAL_GAP",
        },
        "models": {
            "requested_executor": exp.EXECUTOR_MODEL,
            "requested_router": exp.ROUTER_MODEL,
            "returned_executor": sorted(set(row["Returned_Executor_Model"] for row in result_rows)),
            "returned_router": sorted(set(row["Returned_Router_Model"] for row in b_rows)),
        },
        "god_prompt": {
            "target_tokens": exp.GOD_PROMPT_TARGET_TOKENS,
            "local_tokens": manifest["god_prompt_local_tokens"],
            "sha256": manifest["artifact_hashes"]["fixed_artifacts/god_prompt.txt"],
        },
        "runtime": {
            "started_utc": environment["started_utc"],
            "ended_utc": environment["ended_utc"],
            "runtime_seconds": environment["runtime_seconds"],
        },
        "rate_limits": rate_summary,
        "routes": {
            "route_a": a_summary,
            "route_b": {
                "total": b_summary,
                "router": router_summary,
                "executor": executor_summary,
            },
        },
        "paired_analysis": summary_rows,
        "quality_distributions": distributions,
        "router_formula_audit": formula_summary,
        "extreme_cases": extremes,
        "verdict": verdict,
        "artifacts": artifacts,
    }
    exp.generate_figures(RUN_DIR, a_rows, b_rows)
    return summary


def corrected_report(summary: dict[str, object]) -> str:
    report = exp.report_text(summary)
    paired = {row["Metric"]: row for row in summary["paired_analysis"]}
    token_change = float(paired["Total_Tokens"]["Change_vs_A_Percent"])
    original = f"Route B used {abs(token_change):.2f}% fewer\ntotal tokens"
    replacement = (
        f"Route B used {abs(token_change):.2f}% fewer\ntotal tokens"
        if token_change <= 0
        else f"Route B used {abs(token_change):.2f}% more\ntotal tokens"
    )
    report = report.replace(original, replacement)
    integrity_note = (
        "\n- Raw attempt journal: 154/156 successful-call entries. The missing entries are "
        "the measured Route B executor calls for iterations 9 and 35. Their request IDs, "
        "outputs, usage, costs, latencies, and hashes are present and cross-validated in the "
        "primary CSV and final-output journal; unrecoverable raw headers were not fabricated.\n"
    )
    report = report.replace(
        "- Run validity: MEASURED_DATA_COMPLETE_WITH_RAW_JOURNAL_GAP.\n",
        "- Run validity: MEASURED_DATA_COMPLETE_WITH_RAW_JOURNAL_GAP.\n" + integrity_note,
    )
    rate = summary["rate_limits"]
    rate_detail = (
        f"\n- Observed model token-limit header range: "
        f"{rate['rate_limit_token_limit_min']} to {rate['rate_limit_token_limit_max']}.\n"
        f"- Mean retries per logical pipeline: "
        f"{rate['mean_retries_per_logical_pipeline']:.3f}; maximum: "
        f"{rate['maximum_retries_for_one_logical_pipeline']}.\n"
    )
    report = report.replace(
        "were logged, cooled down, and retried without consuming a logical observation.\n",
        "were logged, cooled down, and retried without consuming a logical observation.\n"
        + rate_detail,
    )
    extremes = summary["extreme_cases"]
    examples = (
        "\nClean and correct examples:\n\n~~~~json\n"
        + json.dumps(
            {
                "route_a": extremes["representative_clean_correct_route_a"],
                "route_b": extremes["representative_clean_correct_route_b"],
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n~~~~\n"
    )
    report = report.replace("\n## 17. Limitations\n", examples + "\n## 17. Limitations\n")
    report = report.replace(
        "API proxies. Rate limits influence operational wall time.",
        "API proxies. Rate limits influence operational wall time. Two successful measured "
        "executor calls are fully evidenced by persisted result artifacts but missing from "
        "the append-only raw-attempt journal; no missing headers were reconstructed.",
    )
    return report


def main() -> None:
    summary = build_summary()
    exp.atomic_write_json(RUN_DIR / "analysis_summary.json", summary)
    exp.atomic_write_text(RUN_DIR / "experiment_two_report.md", corrected_report(summary))
    bundle, companion = exp.create_hashes_and_bundle(RUN_DIR)
    checkpoint = exp.load_checkpoint(RUN_DIR)
    checkpoint["publication_status"] = "complete_with_raw_journal_gap"
    checkpoint["bundle_path"] = str(bundle.resolve())
    checkpoint["bundle_sha256_path"] = str(companion.resolve())
    exp.save_checkpoint(RUN_DIR, checkpoint)
    exp.validate_manifest(RUN_DIR)
    print(f"FINALIZED_RUN={RUN_DIR.resolve()}")
    print(f"PUBLICATION_BUNDLE={bundle.resolve()}")


if __name__ == "__main__":
    main()
